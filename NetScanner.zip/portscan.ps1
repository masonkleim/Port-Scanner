<#
.SYNOPSIS
    Command-line port scanner and network device discovery.
.EXAMPLE
    .\portscan.ps1 192.168.1.10                     # scan ports 1-1024 on one host
.EXAMPLE
    .\portscan.ps1 router.local -Ports 22,80,443,8000-8100
.EXAMPLE
    .\portscan.ps1 -Discover                        # list every device on your current network
.EXAMPLE
    .\portscan.ps1 -Discover -Subnet 192.168.1.0/24 -Json
.EXAMPLE
    .\portscan.ps1 -UpdateOui                       # download the IEEE vendor list for better device names
#>
[CmdletBinding(DefaultParameterSetName = 'Ports')]
param(
    [Parameter(ParameterSetName = 'Ports', Mandatory, Position = 0)][string]$Target,
    [Parameter(ParameterSetName = 'Ports')][string]$Ports = '1-1024',
    [Parameter(ParameterSetName = 'Discover', Mandatory)][switch]$Discover,
    [Parameter(ParameterSetName = 'Discover')][string]$Subnet,
    [Parameter(ParameterSetName = 'Discover')][string]$DevicePorts,
    [Parameter(ParameterSetName = 'Discover')][switch]$SkipPorts,
    [Parameter(ParameterSetName = 'Discover')][switch]$AllowLarge,
    [Parameter(ParameterSetName = 'Oui', Mandatory)][switch]$UpdateOui,
    [int]$TimeoutMs = 500,
    [switch]$Json
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'NetScanner.psm1') -Force

switch ($PSCmdlet.ParameterSetName) {
    'Oui' {
        Update-OuiDatabase
    }
    'Ports' {
        $ip = [System.Net.Dns]::GetHostAddresses($Target) |
            Where-Object { $_.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork } |
            Select-Object -First 1
        if (-not $ip) { throw "Could not resolve '$Target' to an IPv4 address." }
        $portList = ConvertTo-PortList $Ports
        Write-Host "Scanning $($portList.Count) ports on $Target ($ip)..." -ForegroundColor DarkGray
        $watch = [System.Diagnostics.Stopwatch]::StartNew()
        $open = @(Invoke-PortScan -Ip $ip.ToString() -Ports $portList -TimeoutMs $TimeoutMs)
        $watch.Stop()
        if ($Json) {
            ConvertTo-Json -Depth 4 -InputObject ([ordered]@{ Target = $Target; Ip = $ip.ToString(); PortsScanned = $portList.Count; OpenPorts = $open })
        } else {
            if ($open.Count) { $open | Format-Table -AutoSize | Out-String | Write-Host }
            else { Write-Host 'No open ports found.' }
            Write-Host ("{0} open of {1} scanned in {2:N1}s" -f $open.Count, $portList.Count, $watch.Elapsed.TotalSeconds) -ForegroundColor DarkGray
        }
    }
    'Discover' {
        $scanArgs = @{
            Subnet        = $Subnet
            Ports         = $DevicePorts
            SkipPorts     = $SkipPorts
            AllowLarge    = $AllowLarge
            PortTimeoutMs = $TimeoutMs
            OnProgress    = { param($m) Write-Host $m -ForegroundColor DarkGray }
        }
        $result = Invoke-NetworkScan @scanArgs
        if ($Json) {
            ConvertTo-Json -Depth 6 -InputObject $result
        } else {
            Write-Host "`n$($result.DeviceCount) devices on $($result.Subnet) via $($result.Interface) (gateway $($result.Gateway)), $($result.DurationSec)s`n"
            $result.Devices | Select-Object Ip, HostName, DeviceType, Vendor, Mac,
                @{ n = 'OpenPorts'; e = { ($_.OpenPorts | ForEach-Object { $_.Port }) -join ',' } } |
                Format-Table -AutoSize -Wrap | Out-String -Width 200 | Write-Host
        }
    }
}
