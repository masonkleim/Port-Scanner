<#
.SYNOPSIS
    Removes NetScanner: shortcuts, the Settings > Apps entry and the install folder.
    -Quiet skips the confirmation dialogs.
#>
param([switch]$Quiet)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework

$appName = 'NetScanner'
$installDir = Join-Path $env:LOCALAPPDATA "Programs\$appName"

if (-not $Quiet) {
    $answer = [System.Windows.MessageBox]::Show('Remove NetScanner from this computer?', 'NetScanner', 'YesNo', 'Question')
    if ($answer -ne 'Yes') { return }
}

try {
    foreach ($link in (Join-Path ([Environment]::GetFolderPath('Desktop')) "$appName.lnk"),
                      (Join-Path ([Environment]::GetFolderPath('Programs')) "$appName.lnk")) {
        Remove-Item -LiteralPath $link -ErrorAction SilentlyContinue
    }
    Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\$appName" -Recurse -ErrorAction SilentlyContinue
    # This script lives in the install folder, so step out of it before deleting.
    Set-Location $env:TEMP
    if (Test-Path $installDir) { Remove-Item -LiteralPath $installDir -Recurse -Force }
    if (-not $Quiet) { [void][System.Windows.MessageBox]::Show('NetScanner has been removed.', 'NetScanner', 'OK', 'Information') }
    'Uninstalled'
} catch {
    if (-not $Quiet) { [void][System.Windows.MessageBox]::Show("Uninstall failed:`n`n$($_.Exception.Message)", 'NetScanner', 'OK', 'Error') }
    throw
}
