@echo off
rem Double-click to install NetScanner (Desktop + Start menu shortcuts, no admin needed).
powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0install.ps1"
