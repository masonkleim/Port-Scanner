# NetScanner.psm1 - network device discovery, TCP port scanning and device-type detection.
# Windows PowerShell 5.1+, no external dependencies.

$script:MaxHostsWithoutOverride = 1024
$script:OuiPath = Join-Path $PSScriptRoot 'oui.tsv'
$script:OuiTable = $null

# Well-known ports used for both service labels and the default device scan.
$script:ServiceNames = @{
    21 = 'FTP'; 22 = 'SSH'; 23 = 'Telnet'; 25 = 'SMTP'; 53 = 'DNS'; 80 = 'HTTP'; 81 = 'HTTP-alt'
    110 = 'POP3'; 135 = 'MS-RPC'; 139 = 'NetBIOS'; 143 = 'IMAP'; 443 = 'HTTPS'; 445 = 'SMB'
    515 = 'LPD (printer)'; 548 = 'AFP (Apple file sharing)'; 554 = 'RTSP (camera/stream)'
    631 = 'IPP (printer)'; 1400 = 'Sonos'; 1883 = 'MQTT'; 3306 = 'MySQL'; 3389 = 'RDP'
    5000 = 'UPnP / Synology'; 5001 = 'Synology HTTPS'; 5432 = 'PostgreSQL'; 5900 = 'VNC'
    7000 = 'AirPlay'; 8008 = 'Chromecast HTTP'; 8009 = 'Chromecast'; 8060 = 'Roku ECP'
    8080 = 'HTTP-alt'; 8123 = 'Home Assistant'; 8443 = 'HTTPS-alt'; 9100 = 'JetDirect (printer)'
    32400 = 'Plex'; 49152 = 'UPnP'; 62078 = 'Apple iOS sync'
}
$script:CommonPorts = [int[]]($script:ServiceNames.Keys | Sort-Object)

# Small fallback vendor table; run Update-OuiDatabase for the full IEEE list.
$script:BuiltInOui = @{
    '00155D' = 'Microsoft (Hyper-V)'; '000C29' = 'VMware'; '005056' = 'VMware'; '000569' = 'VMware'
    '080027' = 'Oracle VirtualBox'; '525400' = 'QEMU / KVM'
    'B827EB' = 'Raspberry Pi'; 'DCA632' = 'Raspberry Pi'; 'E45F01' = 'Raspberry Pi'; 'D83ADD' = 'Raspberry Pi'; '2CCF67' = 'Raspberry Pi'
    '240AC4' = 'Espressif'; '30AEA4' = 'Espressif'; '001132' = 'Synology'; '001788' = 'Philips Lighting'; '000E58' = 'Sonos'
}

#region IP helpers

function ConvertTo-IPNumber {
    param([Parameter(Mandatory)][string]$Ip)
    $address = $null
    if (-not [System.Net.IPAddress]::TryParse($Ip, [ref]$address) -or
        $address.AddressFamily -ne [System.Net.Sockets.AddressFamily]::InterNetwork) {
        throw "'$Ip' is not a valid IPv4 address."
    }
    $b = $address.GetAddressBytes()
    ([long]$b[0] -shl 24) + ([long]$b[1] -shl 16) + ([long]$b[2] -shl 8) + [long]$b[3]
}

function ConvertFrom-IPNumber {
    param([Parameter(Mandatory)][long]$Value)
    '{0}.{1}.{2}.{3}' -f (($Value -shr 24) -band 255), (($Value -shr 16) -band 255), (($Value -shr 8) -band 255), ($Value -band 255)
}

function Get-SubnetInfo {
    param([Parameter(Mandatory)][string]$Cidr)
    $parts = $Cidr.Trim().Split('/')
    $prefix = 32
    if ($parts.Count -gt 1) {
        if ($parts[1] -notmatch '^\d{1,2}$' -or [int]$parts[1] -gt 32) { throw "Invalid prefix length in '$Cidr'." }
        $prefix = [int]$parts[1]
    }
    $ipValue = ConvertTo-IPNumber $parts[0]
    $size = [long][math]::Pow(2, 32 - $prefix)
    $network = $ipValue - ($ipValue % $size)
    $broadcast = $network + $size - 1
    if ($prefix -ge 31) { $first = $network; $last = $broadcast }
    else { $first = $network + 1; $last = $broadcast - 1 }

    [pscustomobject]@{
        Cidr      = "$(ConvertFrom-IPNumber $network)/$prefix"
        Prefix    = $prefix
        Network   = $network
        Broadcast = $broadcast
        FirstHost = $first
        LastHost  = $last
        HostCount = $last - $first + 1
    }
}

function Test-IPInSubnet {
    param([Parameter(Mandatory)][string]$Ip, [Parameter(Mandatory)]$Subnet)
    $n = ConvertTo-IPNumber $Ip
    $n -ge $Subnet.FirstHost -and $n -le $Subnet.LastHost
}

function ConvertTo-PortList {
    param([Parameter(Mandatory)][string]$Spec)
    if ($Spec.Trim() -eq 'common') { return $script:CommonPorts }
    $set = New-Object 'System.Collections.Generic.SortedSet[int]'
    foreach ($part in $Spec.Split(',')) {
        $p = $part.Trim()
        if (-not $p) { continue }
        if ($p -match '^(\d+)\s*-\s*(\d+)$') {
            $from = [int]$Matches[1]; $to = [int]$Matches[2]
        } elseif ($p -match '^\d+$') {
            $from = [int]$p; $to = $from
        } else {
            throw "Invalid port specification '$p'. Use e.g. '22,80,443' or '1-1024'."
        }
        if ($from -lt 1 -or $to -gt 65535 -or $from -gt $to) { throw "Port range '$p' must be within 1-65535." }
        for ($i = $from; $i -le $to; $i++) { [void]$set.Add($i) }
    }
    if ($set.Count -eq 0) { throw 'No ports specified.' }
    [int[]]@($set)
}

function Format-Mac {
    param([string]$Mac)
    if (-not $Mac) { return $null }
    $hex = ($Mac -replace '[^0-9A-Fa-f]', '').ToUpper()
    if ($hex.Length -ne 12) { return $Mac }
    ($hex -split '(..)' | Where-Object { $_ }) -join ':'
}

#endregion

#region Discovery

function Get-LocalNetwork {
    $routes = @(Get-NetRoute -AddressFamily IPv4 -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue)
    $macs = @{}
    Get-NetAdapter -ErrorAction SilentlyContinue | ForEach-Object { $macs[[int]$_.ifIndex] = Format-Mac $_.MacAddress }

    Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
        ForEach-Object {
            $ip = $_
            $route = $routes | Where-Object { $_.InterfaceIndex -eq $ip.InterfaceIndex } | Sort-Object RouteMetric | Select-Object -First 1
            $metric = [int]::MaxValue
            if ($route) {
                $ifMetric = (Get-NetIPInterface -InterfaceIndex $ip.InterfaceIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).InterfaceMetric
                $metric = [int]$route.RouteMetric + [int]$ifMetric
            }
            $subnet = Get-SubnetInfo "$($ip.IPAddress)/$($ip.PrefixLength)"
            [pscustomobject][ordered]@{
                InterfaceAlias = $ip.InterfaceAlias
                InterfaceIndex = [int]$ip.InterfaceIndex
                IpAddress      = $ip.IPAddress
                Mac            = $macs[[int]$ip.InterfaceIndex]
                Cidr           = $subnet.Cidr
                HostCount      = $subnet.HostCount
                Gateway        = if ($route) { $route.NextHop } else { $null }
                Metric         = $metric
            }
        }
}

# Validates a scan target and picks the matching local interface. Throws on bad input or oversized ranges.
function Resolve-ScanTarget {
    param([string]$Subnet, [switch]$AllowLarge)
    $networks = @(Get-LocalNetwork)
    if ($Subnet) {
        $info = Get-SubnetInfo $Subnet
        $iface = $networks | Where-Object { Test-IPInSubnet $_.IpAddress $info } | Select-Object -First 1
    } else {
        $iface = $networks | Where-Object { $_.Gateway } | Sort-Object Metric | Select-Object -First 1
        if (-not $iface) { throw 'No network with a default gateway was found. Specify a subnet, e.g. 192.168.1.0/24.' }
        $info = Get-SubnetInfo $iface.Cidr
    }
    if ($info.HostCount -gt $script:MaxHostsWithoutOverride -and -not $AllowLarge) {
        throw ("Subnet $($info.Cidr) has $($info.HostCount) addresses; scans are limited to $script:MaxHostsWithoutOverride " +
               "unless AllowLarge is set. Networks this size are usually shared (campus, office, hotel) - only scan networks you own or have permission to scan. " +
               "You can also target a smaller range, e.g. one /24.")
    }
    [pscustomobject]@{ Subnet = $info; Interface = $iface; LocalNetworks = $networks }
}

function Invoke-PingSweep {
    param([Parameter(Mandatory)][string[]]$Addresses, [int]$TimeoutMs = 600, [int]$BatchSize = 256)
    for ($i = 0; $i -lt $Addresses.Count; $i += $BatchSize) {
        $end = [math]::Min($i + $BatchSize, $Addresses.Count) - 1
        $pending = foreach ($addr in $Addresses[$i..$end]) {
            $ping = New-Object System.Net.NetworkInformation.Ping
            [pscustomobject]@{ Ip = $addr; Ping = $ping; Task = $ping.SendPingAsync($addr, $TimeoutMs) }
        }
        try { [void][System.Threading.Tasks.Task]::WaitAll([System.Threading.Tasks.Task[]]@($pending.Task), $TimeoutMs + 2000) } catch { }
        foreach ($p in $pending) {
            if ($p.Task.Status -eq 'RanToCompletion' -and $p.Task.Result.Status -eq 'Success') {
                $ttl = $null
                if ($p.Task.Result.Options) { $ttl = $p.Task.Result.Options.Ttl }
                [pscustomobject]@{ Ip = $p.Ip; RoundtripMs = $p.Task.Result.RoundtripTime; Ttl = $ttl }
            }
            $p.Ping.Dispose()
        }
    }
}

function Get-ArpEntry {
    Get-NetNeighbor -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Where-Object {
            $_.State -notin 'Unreachable', 'Incomplete' -and $_.LinkLayerAddress -and
            $_.LinkLayerAddress -notin '00-00-00-00-00-00', 'FF-FF-FF-FF-FF-FF' -and
            -not $_.LinkLayerAddress.StartsWith('01-00-5E')
        } |
        ForEach-Object { [pscustomobject]@{ Ip = $_.IPAddress; Mac = Format-Mac $_.LinkLayerAddress; State = [string]$_.State } }
}

function Resolve-HostName {
    param([string[]]$Addresses, [int]$TimeoutMs = 2500)
    $names = @{}
    if (-not $Addresses) { return $names }
    $pending = foreach ($a in $Addresses) { [pscustomobject]@{ Ip = $a; Task = [System.Net.Dns]::GetHostEntryAsync($a) } }
    try { [void][System.Threading.Tasks.Task]::WaitAll([System.Threading.Tasks.Task[]]@($pending.Task), $TimeoutMs) } catch { }
    foreach ($p in $pending) {
        if ($p.Task.Status -eq 'RanToCompletion' -and $p.Task.Result.HostName -and $p.Task.Result.HostName -ne $p.Ip) {
            $names[$p.Ip] = $p.Task.Result.HostName
        }
    }
    $names
}

#endregion

#region Port scanning

function Invoke-PortScan {
    param(
        [Parameter(Mandatory)][string]$Ip,
        [Parameter(Mandatory)][int[]]$Ports,
        [int]$TimeoutMs = 500,
        [int]$BatchSize = 200
    )
    for ($i = 0; $i -lt $Ports.Count; $i += $BatchSize) {
        $end = [math]::Min($i + $BatchSize, $Ports.Count) - 1
        $pending = foreach ($port in $Ports[$i..$end]) {
            $client = New-Object System.Net.Sockets.TcpClient
            [pscustomobject]@{ Port = $port; Client = $client; Task = $client.ConnectAsync($Ip, $port) }
        }
        try { [void][System.Threading.Tasks.Task]::WaitAll([System.Threading.Tasks.Task[]]@($pending.Task), $TimeoutMs) } catch { }
        foreach ($p in $pending) {
            if ($p.Task.Status -eq 'RanToCompletion' -and $p.Client.Connected) {
                $service = $script:ServiceNames[$p.Port]
                if (-not $service) { $service = 'unknown' }
                [pscustomobject]@{ Port = $p.Port; Service = $service }
            }
            $p.Client.Close()
        }
    }
}

#endregion

#region Identification

function Update-OuiDatabase {
    param([string]$Uri = 'https://standards-oui.ieee.org/oui/oui.txt')
    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor [System.Net.SecurityProtocolType]::Tls12
    $tmp = [System.IO.Path]::GetTempFileName()
    try {
        Invoke-WebRequest -Uri $Uri -OutFile $tmp -UseBasicParsing -UserAgent 'Mozilla/5.0 (NetScanner)'
        $out = New-Object System.Collections.Generic.List[string]
        foreach ($line in [System.IO.File]::ReadLines($tmp)) {
            if ($line -match '^\s*([0-9A-F]{2})-([0-9A-F]{2})-([0-9A-F]{2})\s+\(hex\)\s+(.+?)\s*$') {
                $out.Add("$($Matches[1])$($Matches[2])$($Matches[3])`t$($Matches[4])")
            }
        }
        [System.IO.File]::WriteAllLines($script:OuiPath, $out)
        $script:OuiTable = $null
        "Saved $($out.Count) vendor prefixes to $script:OuiPath"
    } finally {
        Remove-Item $tmp -ErrorAction SilentlyContinue
    }
}

function Get-MacVendor {
    param([string]$Mac)
    if (-not $Mac) { return $null }
    $hex = ($Mac -replace '[^0-9A-Fa-f]', '').ToUpper()
    if ($hex.Length -lt 6) { return $null }
    if ($null -eq $script:OuiTable) {
        $script:OuiTable = @{}
        if (Test-Path $script:OuiPath) {
            foreach ($line in [System.IO.File]::ReadAllLines($script:OuiPath)) {
                if ($line.Length -gt 7 -and $line[6] -eq "`t") { $script:OuiTable[$line.Substring(0, 6)] = $line.Substring(7) }
            }
        }
    }
    $prefix = $hex.Substring(0, 6)
    if ($script:OuiTable.ContainsKey($prefix)) { return $script:OuiTable[$prefix] }
    $script:BuiltInOui[$prefix]
}

# Locally-administered bit set: phones/laptops use these for Wi-Fi privacy.
function Test-RandomizedMac {
    param([string]$Mac)
    if (-not $Mac) { return $false }
    $first = [Convert]::ToInt32(($Mac -replace '[^0-9A-Fa-f]', '').Substring(0, 2), 16)
    ($first -band 2) -ne 0
}

function Get-OsGuess {
    param($Ttl)
    if (-not $Ttl) { return $null }
    if ($Ttl -le 64) { 'Linux / macOS / iOS / Android' }
    elseif ($Ttl -le 128) { 'Windows' }
    else { 'Network equipment / embedded' }
}

function Get-DeviceType {
    param([Parameter(Mandatory)]$Device)
    $ports = @($Device.OpenPorts | ForEach-Object { $_.Port })
    $vendor = [string]$Device.Vendor
    $has = { param([int[]]$Wanted) foreach ($w in $Wanted) { if ($ports -contains $w) { return $true } }; $false }
    $list = { param([int[]]$Wanted) ($Wanted | Where-Object { $ports -contains $_ }) -join ', ' }

    if ($Device.IsLocal) { return @{ Type = 'This computer'; Reason = 'Address belongs to this machine' } }
    if ($Device.IsGateway) { return @{ Type = 'Router / gateway'; Reason = 'Default gateway for this network' } }
    if (& $has 9100, 515, 631) { return @{ Type = 'Printer'; Reason = "Printer port(s) open: $(& $list 9100, 515, 631)" } }
    if ($vendor -match 'VMware|VirtualBox|QEMU|Hyper-V') { return @{ Type = 'Virtual machine'; Reason = "Virtualization vendor: $vendor" } }
    if ($vendor -match 'Raspberry') { return @{ Type = 'Raspberry Pi'; Reason = "Vendor: $vendor" } }
    if (& $has 62078) { return @{ Type = 'iPhone / iPad'; Reason = 'Apple iOS sync port 62078 open' } }
    if (& $has 8008, 8009) { return @{ Type = 'Chromecast / Google smart device'; Reason = "Cast port(s) open: $(& $list 8008, 8009)" } }
    if (& $has 8060) { return @{ Type = 'Roku streaming device'; Reason = 'Roku control port 8060 open' } }
    if ((& $has 1400) -or $vendor -match 'Sonos') { return @{ Type = 'Sonos speaker'; Reason = 'Sonos port 1400 open or Sonos vendor' } }
    if (& $has 554) { return @{ Type = 'IP camera / video streamer'; Reason = 'RTSP port 554 open' } }
    if ($vendor -match 'Synology|QNAP' -or ((& $has 5000, 5001) -and (& $has 445, 548))) { return @{ Type = 'NAS / file server'; Reason = 'NAS vendor or NAS admin + file-sharing ports' } }
    if (& $has 32400) { return @{ Type = 'Media server (Plex)'; Reason = 'Plex port 32400 open' } }
    if (& $has 8123, 1883) { return @{ Type = 'Smart-home hub'; Reason = "Home automation port(s) open: $(& $list 8123, 1883)" } }
    if ($vendor -match 'Espressif|Tuya|Shelly|Philips Lighting|Signify|Tp-Link Systems|Wyze|Ring') { return @{ Type = 'IoT / smart-home device'; Reason = "Vendor: $vendor" } }
    if ((& $has 3389) -or ((& $has 135) -and (& $has 445))) { return @{ Type = 'Windows PC'; Reason = "Windows port(s) open: $(& $list 3389, 135, 445)" } }
    if ((& $has 7000, 548) -or $vendor -match 'Apple') { return @{ Type = 'Apple device (Mac / Apple TV / iOS)'; Reason = 'AirPlay/AFP port open or Apple vendor' } }
    if ($vendor -match 'Samsung|LG Electronics|Sony|Vizio|Hisense|TCL|Roku|Amazon') { return @{ Type = 'Smart TV / media / consumer device'; Reason = "Vendor: $vendor" } }
    if (& $has 22) { return @{ Type = 'Linux / Unix host'; Reason = 'SSH port 22 open' } }
    if (& $has 80, 443, 8080, 8443) { return @{ Type = 'Web-managed device'; Reason = "Web port(s) open: $(& $list 80, 443, 8080, 8443)" } }
    if ($Device.RandomizedMac) { return @{ Type = 'Phone / tablet / laptop (private MAC)'; Reason = 'Randomized MAC address, typical of modern phones and laptops' } }
    if ($Device.OsGuess) { return @{ Type = "Unknown ($($Device.OsGuess))"; Reason = "Guessed from ping TTL $($Device.Ttl)" } }
    @{ Type = 'Unknown device'; Reason = 'No identifying ports or vendor information' }
}

#endregion

function Invoke-NetworkScan {
    [CmdletBinding()]
    param(
        [string]$Subnet,
        [string]$Ports,
        [switch]$SkipPorts,
        [int]$PingTimeoutMs = 600,
        [int]$PortTimeoutMs = 500,
        [switch]$AllowLarge,
        [scriptblock]$OnProgress
    )
    $started = Get-Date
    $report = { param($Message) Write-Verbose $Message; if ($OnProgress) { & $OnProgress $Message } }

    $target = Resolve-ScanTarget -Subnet $Subnet -AllowLarge:$AllowLarge
    $info = $target.Subnet
    $portList = @()
    if (-not $SkipPorts) {
        if ($Ports) { $portList = ConvertTo-PortList $Ports } else { $portList = $script:CommonPorts }
    }

    $addresses = for ($n = $info.FirstHost; $n -le $info.LastHost; $n++) { ConvertFrom-IPNumber $n }
    & $report "Pinging $($addresses.Count) addresses in $($info.Cidr)..."
    $alive = @{}
    foreach ($r in Invoke-PingSweep -Addresses $addresses -TimeoutMs $PingTimeoutMs) { $alive[$r.Ip] = $r }

    # The sweep fills the ARP cache, which also reveals devices that ignore ping.
    & $report 'Reading ARP table...'
    $arp = @{}
    foreach ($e in Get-ArpEntry) { if (Test-IPInSubnet $e.Ip $info) { $arp[$e.Ip] = $e } }

    $local = @{}
    foreach ($n in $target.LocalNetworks) { if (Test-IPInSubnet $n.IpAddress $info) { $local[$n.IpAddress] = $n } }

    $ips = @(@($alive.Keys) + @($arp.Keys) + @($local.Keys) | Sort-Object { ConvertTo-IPNumber $_ } -Unique)
    $gateway = $null
    if ($target.Interface) { $gateway = $target.Interface.Gateway }

    & $report "Resolving host names for $($ips.Count) devices..."
    $names = Resolve-HostName -Addresses $ips

    $devices = New-Object System.Collections.Generic.List[object]
    $index = 0
    foreach ($ip in $ips) {
        $index++
        $isLocal = $local.ContainsKey($ip)
        $mac = $null
        if ($arp.ContainsKey($ip)) { $mac = $arp[$ip].Mac } elseif ($isLocal) { $mac = $local[$ip].Mac }
        $hostName = $names[$ip]
        if (-not $hostName -and $isLocal) { $hostName = $env:COMPUTERNAME }

        $openPorts = @()
        if ($portList.Count) {
            & $report "Scanning $($portList.Count) ports on $ip ($index of $($ips.Count))..."
            $openPorts = @(Invoke-PortScan -Ip $ip -Ports $portList -TimeoutMs $PortTimeoutMs)
        }
        $ping = $alive[$ip]
        $ttl = $null; $latency = $null
        if ($ping) { $ttl = $ping.Ttl; $latency = $ping.RoundtripMs }

        $device = [pscustomobject][ordered]@{
            Ip             = $ip
            HostName       = $hostName
            DeviceType     = $null
            TypeReason     = $null
            Vendor         = Get-MacVendor $mac
            Mac            = $mac
            RandomizedMac  = Test-RandomizedMac $mac
            OsGuess        = Get-OsGuess $ttl
            Ttl            = $ttl
            LatencyMs      = $latency
            RespondsToPing = [bool]$ping
            IsGateway      = ($ip -eq $gateway)
            IsLocal        = $isLocal
            OpenPorts      = $openPorts
        }
        $class = Get-DeviceType $device
        $device.DeviceType = $class.Type
        $device.TypeReason = $class.Reason
        $devices.Add($device)
    }

    $finished = Get-Date
    $interfaceName = $null
    if ($target.Interface) { $interfaceName = $target.Interface.InterfaceAlias }
    [pscustomobject][ordered]@{
        Subnet       = $info.Cidr
        Interface    = $interfaceName
        Gateway      = $gateway
        StartedAt    = $started.ToString('o')
        FinishedAt   = $finished.ToString('o')
        DurationSec  = [math]::Round(($finished - $started).TotalSeconds, 1)
        PortsScanned = $portList.Count
        DeviceCount  = $devices.Count
        Devices      = $devices.ToArray()
    }
}

Export-ModuleMember -Function Invoke-NetworkScan, Invoke-PortScan, Invoke-PingSweep, Resolve-ScanTarget, Get-LocalNetwork,
    Get-SubnetInfo, ConvertTo-PortList, ConvertTo-IPNumber, Get-ArpEntry, Get-MacVendor, Get-DeviceType, Update-OuiDatabase
