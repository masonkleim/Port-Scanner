@echo off
rem Double-click to open the NetScanner desktop app.
start "" powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0NetScannerApp.ps1"
