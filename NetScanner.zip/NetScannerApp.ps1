<#
.SYNOPSIS
    NetScanner desktop app: scans the network and draws every device on a map.
.DESCRIPTION
    Launch with NetScanner.bat (double-click) or:
        powershell -STA -ExecutionPolicy Bypass -File .\NetScannerApp.ps1
    -Open <file.json>   loads a scan previously saved with "Save".
    -Snapshot <file.png> renders the window to an image and exits (used for testing, with -Select / -List).
#>
param(
    [string]$Open,
    [string]$Snapshot,
    [string]$Select,
    [switch]$List
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

try {
$modulePath = Join-Path $PSScriptRoot 'NetScanner.psm1'
Import-Module $modulePath -Force

# Device categories: first regex match on DeviceType wins. Glyphs are from the built-in Segoe MDL2 Assets font.
$script:Categories = @(
    @{ Match = '^This computer';          Name = 'This computer';     Glyph = 0xE7F8; Color = '#4C8DFF' }
    @{ Match = '^Router';                 Name = 'Router / gateway';  Glyph = 0xE957; Color = '#F5A524' }
    @{ Match = '^Windows PC';             Name = 'Windows PC';        Glyph = 0xE977; Color = '#3FB6F2' }
    @{ Match = '^Apple';                  Name = 'Apple device';      Glyph = 0xE770; Color = '#C9CED8' }
    @{ Match = 'iPhone|Phone';            Name = 'Phone / tablet';    Glyph = 0xE8EA; Color = '#B48CFF' }
    @{ Match = 'Printer';                 Name = 'Printer';           Glyph = 0xE749; Color = '#2EC4A6' }
    @{ Match = 'camera';                  Name = 'Camera';            Glyph = 0xE722; Color = '#FF6B6B' }
    @{ Match = 'Sonos';                   Name = 'Speaker';           Glyph = 0xE7F5; Color = '#FF9F6B' }
    @{ Match = 'Chromecast|Roku|TV';      Name = 'TV / streaming';    Glyph = 0xE7F4; Color = '#FF7EB6' }
    @{ Match = 'NAS';                     Name = 'NAS / storage';     Glyph = 0xEDA2; Color = '#8BD45E' }
    @{ Match = 'Media server';            Name = 'Media server';      Glyph = 0xE8B2; Color = '#E5C55A' }
    @{ Match = 'Smart-home hub';          Name = 'Smart-home hub';    Glyph = 0xE80F; Color = '#5ED4C9' }
    @{ Match = 'IoT';                     Name = 'IoT device';        Glyph = 0xE950; Color = '#62D99A' }
    @{ Match = 'Raspberry';               Name = 'Raspberry Pi';      Glyph = 0xE964; Color = '#E8556D' }
    @{ Match = 'Virtual machine';         Name = 'Virtual machine';   Glyph = 0xE703; Color = '#8E9AFF' }
    @{ Match = 'Linux';                   Name = 'Linux / Unix host'; Glyph = 0xE756; Color = '#D7DB5E' }
    @{ Match = 'Web-managed';             Name = 'Web-managed device'; Glyph = 0xE774; Color = '#6FC3FF' }
    @{ Match = '.';                       Name = 'Unknown';           Glyph = 0xE9CE; Color = '#7D8699' }
)
$script:NetworkGlyph = 0xE968

$script:Result = $null
$script:SelectedIp = $null
$script:WasRunning = $false
$state = [hashtable]::Synchronized(@{ Status = 'idle'; Kind = $null; Progress = $null; Error = $null; Result = $null; Target = $null })
$script:Job = $null
$brushConverter = New-Object System.Windows.Media.BrushConverter
$mdl2 = New-Object System.Windows.Media.FontFamily 'Segoe MDL2 Assets'

[xml]$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="NetScanner" Width="1280" Height="800" MinWidth="960" MinHeight="600"
        Background="#11151C" Foreground="#E6E9EF" FontFamily="Segoe UI" FontSize="13"
        WindowStartupLocation="CenterScreen">
  <Window.Resources>
    <Style TargetType="TextBox">
      <Setter Property="Background" Value="#0D1117"/>
      <Setter Property="Foreground" Value="#E6E9EF"/>
      <Setter Property="BorderBrush" Value="#2C3443"/>
      <Setter Property="CaretBrush" Value="#E6E9EF"/>
      <Setter Property="Padding" Value="6,5"/>
      <Setter Property="VerticalContentAlignment" Value="Center"/>
    </Style>
    <Style x:Key="Btn" TargetType="Button">
      <Setter Property="Foreground" Value="#E6E9EF"/>
      <Setter Property="Background" Value="#232A36"/>
      <Setter Property="Padding" Value="14,7"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="B" Background="{TemplateBinding Background}" CornerRadius="6" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="B" Property="Opacity" Value="0.85"/></Trigger>
              <Trigger Property="IsEnabled" Value="False"><Setter TargetName="B" Property="Opacity" Value="0.4"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
    <Style x:Key="Primary" TargetType="Button" BasedOn="{StaticResource Btn}">
      <Setter Property="Background" Value="#2F6FDE"/>
      <Setter Property="Foreground" Value="White"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
    </Style>
    <Style TargetType="DataGridColumnHeader">
      <Setter Property="Background" Value="#171C25"/>
      <Setter Property="Foreground" Value="#8A93A6"/>
      <Setter Property="Padding" Value="10,8"/>
      <Setter Property="BorderBrush" Value="#262D3A"/>
      <Setter Property="BorderThickness" Value="0,0,0,1"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
    </Style>
    <Style TargetType="DataGridCell">
      <Setter Property="Padding" Value="10,6"/>
      <Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="DataGridCell">
            <Border Padding="{TemplateBinding Padding}" Background="{TemplateBinding Background}"><ContentPresenter/></Border>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
      <Style.Triggers>
        <Trigger Property="IsSelected" Value="True">
          <Setter Property="Background" Value="#24324A"/>
          <Setter Property="Foreground" Value="#E6E9EF"/>
        </Trigger>
      </Style.Triggers>
    </Style>
  </Window.Resources>

  <Grid x:Name="Root" Background="#11151C">
    <Grid.RowDefinitions>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="*"/>
      <RowDefinition Height="Auto"/>
    </Grid.RowDefinitions>

    <Border Grid.Row="0" Background="#171C25" BorderBrush="#262D3A" BorderThickness="0,0,0,1" Padding="18,12">
      <DockPanel LastChildFill="False">
        <StackPanel DockPanel.Dock="Left" VerticalAlignment="Center">
          <TextBlock Text="NetScanner" FontSize="20" FontWeight="SemiBold"/>
          <TextBlock x:Name="NetworkText" Foreground="#8A93A6" Text="Detecting network..."/>
        </StackPanel>
        <StackPanel DockPanel.Dock="Right" Orientation="Horizontal" VerticalAlignment="Center">
          <TextBlock Text="Subnet" Foreground="#8A93A6" VerticalAlignment="Center" Margin="0,0,6,0"/>
          <TextBox x:Name="SubnetBox" Width="150" ToolTip="Leave blank for your current network, or enter e.g. 192.168.1.0/24"/>
          <TextBlock Text="Ports" Foreground="#8A93A6" VerticalAlignment="Center" Margin="12,0,6,0"/>
          <TextBox x:Name="PortsBox" Width="120" ToolTip="Leave blank for 36 common ports, or e.g. 22,80,443,8000-8100"/>
          <Button x:Name="ScanButton" Content="Scan network" Style="{StaticResource Primary}" Margin="12,0,0,0"/>
          <Button x:Name="OpenButton" Content="Open" Style="{StaticResource Btn}" Margin="8,0,0,0" ToolTip="Open a saved scan (.json)"/>
          <Button x:Name="SaveButton" Content="Save" Style="{StaticResource Btn}" Margin="8,0,0,0" IsEnabled="False" ToolTip="Save the scan as JSON or CSV"/>
        </StackPanel>
      </DockPanel>
    </Border>

    <Grid Grid.Row="1">
      <Grid.ColumnDefinitions>
        <ColumnDefinition Width="*"/>
        <ColumnDefinition Width="340"/>
      </Grid.ColumnDefinitions>

      <Grid Grid.Column="0" x:Name="MapArea" Background="#11151C">
        <Viewbox x:Name="MapView" Stretch="Uniform" StretchDirection="DownOnly" Margin="16,52,16,16">
          <Canvas x:Name="MapCanvas" Width="900" Height="640" Background="Transparent"/>
        </Viewbox>
        <DataGrid x:Name="DeviceGrid" Visibility="Collapsed" Margin="16,52,16,16" AutoGenerateColumns="False" IsReadOnly="True"
                  Background="#11151C" RowBackground="#151A22" AlternatingRowBackground="#121720" Foreground="#E6E9EF"
                  BorderBrush="#262D3A" GridLinesVisibility="None" HeadersVisibility="Column" SelectionMode="Single"
                  CanUserResizeRows="False" RowHeaderWidth="0">
          <DataGrid.Columns>
            <DataGridTextColumn Header="IP" Binding="{Binding Ip}" Width="110"/>
            <DataGridTextColumn Header="Name" Binding="{Binding Name}" Width="1.2*"/>
            <DataGridTextColumn Header="Type" Binding="{Binding DeviceType}" Width="1.3*"/>
            <DataGridTextColumn Header="Vendor" Binding="{Binding Vendor}" Width="*"/>
            <DataGridTextColumn Header="MAC" Binding="{Binding Mac}" Width="130"/>
            <DataGridTextColumn Header="Open ports" Binding="{Binding Ports}" Width="*"/>
          </DataGrid.Columns>
        </DataGrid>
        <StackPanel x:Name="EmptyState" HorizontalAlignment="Center" VerticalAlignment="Center">
          <TextBlock x:Name="EmptyIcon" FontFamily="Segoe MDL2 Assets" FontSize="64" Foreground="#2F3A4D" HorizontalAlignment="Center"/>
          <TextBlock Text="No scan yet" FontSize="18" FontWeight="SemiBold" HorizontalAlignment="Center" Margin="0,14,0,4"/>
          <TextBlock Text="Click Scan network to find every device on your network." Foreground="#8A93A6" HorizontalAlignment="Center"/>
        </StackPanel>
        <StackPanel Orientation="Horizontal" HorizontalAlignment="Left" VerticalAlignment="Top" Margin="16,14,0,0">
          <Button x:Name="MapTab" Content="Map" Style="{StaticResource Btn}" Padding="16,6"/>
          <Button x:Name="ListTab" Content="List" Style="{StaticResource Btn}" Padding="16,6" Margin="6,0,0,0"/>
        </StackPanel>
      </Grid>

      <Border Grid.Column="1" Background="#171C25" BorderBrush="#262D3A" BorderThickness="1,0,0,0">
        <ScrollViewer VerticalScrollBarVisibility="Auto">
          <StackPanel x:Name="DetailsPanel" Margin="20"/>
        </ScrollViewer>
      </Border>
    </Grid>

    <Border Grid.Row="2" Background="#171C25" BorderBrush="#262D3A" BorderThickness="0,1,0,0" Padding="18,7">
      <DockPanel>
        <ProgressBar x:Name="Busy" DockPanel.Dock="Left" Width="120" Height="4" IsIndeterminate="True" Visibility="Collapsed"
                     Margin="0,0,12,0" Background="#232A36" Foreground="#2F6FDE" BorderThickness="0"/>
        <TextBlock x:Name="StatusText" Foreground="#8A93A6" Text="Ready."/>
      </DockPanel>
    </Border>
  </Grid>
</Window>
'@

$window = [System.Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $xaml))
$ui = @{}
foreach ($name in 'NetworkText', 'SubnetBox', 'PortsBox', 'ScanButton', 'OpenButton', 'SaveButton', 'MapView', 'MapCanvas',
                  'DeviceGrid', 'EmptyState', 'EmptyIcon', 'MapTab', 'ListTab', 'DetailsPanel', 'Busy', 'StatusText', 'Root') {
    $ui[$name] = $window.FindName($name)
}
$ui.EmptyIcon.Text = [string][char]$script:NetworkGlyph
$iconPath = Join-Path $PSScriptRoot 'NetScanner.ico'
if (Test-Path $iconPath) {
    # OnLoad reads the file fully so it isn't kept locked (lets the installer update it while the app runs).
    $window.Icon = [System.Windows.Media.Imaging.BitmapFrame]::Create([Uri]$iconPath,
        [System.Windows.Media.Imaging.BitmapCreateOptions]::None, [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad)
}

#region Helpers

function Get-Brush([string]$Hex) { $brushConverter.ConvertFromString($Hex) }

function Get-Category([string]$Type) {
    foreach ($c in $script:Categories) { if ($Type -match $c.Match) { return $c } }
}

function Get-DisplayName($Device) {
    if ($Device.HostName) { return ($Device.HostName -split '\.')[0] }
    if ($Device.Vendor) { return $Device.Vendor }
    $Device.Ip
}

function Set-Status([string]$Text, [bool]$IsBusy = $false, [bool]$IsError = $false) {
    $ui.StatusText.Text = $Text
    $ui.StatusText.Foreground = Get-Brush $(if ($IsError) { '#FF7B6E' } else { '#8A93A6' })
    $ui.Busy.Visibility = $(if ($IsBusy) { 'Visible' } else { 'Collapsed' })
    $ui.ScanButton.IsEnabled = -not $IsBusy
}

function New-Text {
    param([string]$Text, [double]$Size = 13, [string]$Color = '#E6E9EF', [string]$Weight = 'Normal', [string]$Margin = '0,0,0,4')
    New-Object System.Windows.Controls.TextBlock -Property @{
        Text = $Text; FontSize = $Size; Foreground = (Get-Brush $Color); FontWeight = $Weight; Margin = $Margin; TextWrapping = 'Wrap'
    }
}

function New-IconBadge {
    param($Category, [double]$Size, [bool]$Selected = $false, [int]$Glyph = 0)
    if (-not $Glyph) { $Glyph = $Category.Glyph }
    $grid = New-Object System.Windows.Controls.Grid -Property @{ Width = $Size; Height = $Size }
    if ($Selected) {
        $halo = New-Object System.Windows.Shapes.Ellipse -Property @{
            Width = $Size + 16; Height = $Size + 16; Margin = '-8'; Fill = (Get-Brush ($Category.Color -replace '^#', '#33'))
        }
        [void]$grid.Children.Add($halo)
    }
    $circle = New-Object System.Windows.Shapes.Ellipse -Property @{
        Fill = (Get-Brush '#1B212C'); Stroke = (Get-Brush $Category.Color); StrokeThickness = $(if ($Selected) { 3 } else { 2 })
    }
    $icon = New-Object System.Windows.Controls.TextBlock -Property @{
        Text = [string][char]$Glyph; FontFamily = $mdl2; FontSize = [math]::Round($Size * 0.42)
        Foreground = (Get-Brush $Category.Color); HorizontalAlignment = 'Center'; VerticalAlignment = 'Center'
    }
    [void]$grid.Children.Add($circle)
    [void]$grid.Children.Add($icon)
    $grid
}

#endregion

#region Map

function Update-Map {
    $canvas = $ui.MapCanvas
    $canvas.Children.Clear()
    $devices = @()
    if ($script:Result) { $devices = @($script:Result.Devices) }
    $ui.EmptyState.Visibility = $(if ($devices.Count) { 'Collapsed' } else { 'Visible' })
    if (-not $devices.Count) { return }

    $hub = $devices | Where-Object { $_.IsGateway } | Select-Object -First 1
    $others = @($devices | Where-Object { $_ -ne $hub } | Sort-Object `
        @{ e = { [array]::IndexOf(@($script:Categories | ForEach-Object { $_.Name }), (Get-Category $_.DeviceType).Name) } },
        @{ e = { ConvertTo-IPNumber $_.Ip } })

    # Fill elliptical rings outward; capacity grows with circumference.
    $rings = @()
    $remaining = $others.Count
    $radius = 200
    while ($remaining -gt 0) {
        $capacity = [math]::Max(6, [math]::Floor(2 * [math]::PI * $radius / 130))
        $take = [math]::Min($capacity, $remaining)
        $rings += , @($radius, $take)
        $remaining -= $take
        $radius += 150
    }
    $stretch = 1.45
    $maxRadius = 0
    if ($rings.Count) { $maxRadius = $rings[-1][0] }
    $canvas.Width = [math]::Max(900, 2 * ($maxRadius * $stretch + 100))
    $canvas.Height = [math]::Max(640, 2 * ($maxRadius + 95))
    $cx = $canvas.Width / 2
    $cy = $canvas.Height / 2

    # Guide rings
    foreach ($ring in $rings) {
        $r = $ring[0]
        $guide = New-Object System.Windows.Shapes.Ellipse -Property @{
            Width = 2 * $r * $stretch; Height = 2 * $r; Stroke = (Get-Brush '#1F2633'); StrokeThickness = 1
            StrokeDashArray = (New-Object System.Windows.Media.DoubleCollection (, [double[]](4, 6)))
        }
        [System.Windows.Controls.Canvas]::SetLeft($guide, $cx - $r * $stretch)
        [System.Windows.Controls.Canvas]::SetTop($guide, $cy - $r)
        [void]$canvas.Children.Add($guide)
    }

    # Positions
    $placed = @()
    $index = 0
    for ($k = 0; $k -lt $rings.Count; $k++) {
        $r = $rings[$k][0]; $take = $rings[$k][1]
        $offset = $(if ($k % 2) { [math]::PI / $take } else { 0 })
        for ($j = 0; $j -lt $take; $j++) {
            $angle = -[math]::PI / 2 + $offset + $j * 2 * [math]::PI / $take
            $placed += , @($others[$index], ($cx + $r * $stretch * [math]::Cos($angle)), ($cy + $r * [math]::Sin($angle)))
            $index++
        }
    }

    # Links first so nodes draw on top
    foreach ($p in $placed) {
        $selected = $p[0].Ip -eq $script:SelectedIp
        $line = New-Object System.Windows.Shapes.Line -Property @{
            X1 = $cx; Y1 = $cy; X2 = $p[1]; Y2 = $p[2]
            Stroke = (Get-Brush $(if ($selected) { (Get-Category $p[0].DeviceType).Color } else { '#283041' }))
            StrokeThickness = $(if ($selected) { 2.5 } else { 1.5 })
        }
        [void]$canvas.Children.Add($line)
    }

    # Hub (router, or a generic network node when no gateway was found)
    if ($hub) {
        Add-MapNode $canvas $hub $cx $cy 92
    } else {
        $category = @{ Name = 'Network'; Color = '#F5A524'; Glyph = $script:NetworkGlyph }
        $node = New-NodeVisual $category 92 'Network' $script:Result.Subnet $false
        [System.Windows.Controls.Canvas]::SetLeft($node, $cx - 70)
        [System.Windows.Controls.Canvas]::SetTop($node, $cy - 46)
        [void]$canvas.Children.Add($node)
    }
    foreach ($p in $placed) { Add-MapNode $canvas $p[0] $p[1] $p[2] 62 }
}

function New-NodeVisual {
    param($Category, [double]$Size, [string]$Title, [string]$Subtitle, [bool]$Selected)
    $stack = New-Object System.Windows.Controls.StackPanel -Property @{ Width = 140; Background = (Get-Brush '#00000000') }
    $badge = New-IconBadge $Category $Size $Selected
    $badge.HorizontalAlignment = 'Center'
    [void]$stack.Children.Add($badge)
    $label = New-Object System.Windows.Controls.TextBlock -Property @{
        Text = $Title; FontWeight = 'SemiBold'; FontSize = 13; Foreground = (Get-Brush '#E6E9EF')
        HorizontalAlignment = 'Center'; TextTrimming = 'CharacterEllipsis'; MaxWidth = 136; Margin = '0,7,0,0'
    }
    $sub = New-Object System.Windows.Controls.TextBlock -Property @{
        Text = $Subtitle; FontSize = 11.5; Foreground = (Get-Brush '#8A93A6'); HorizontalAlignment = 'Center'
        TextTrimming = 'CharacterEllipsis'; MaxWidth = 136
    }
    [void]$stack.Children.Add($label)
    [void]$stack.Children.Add($sub)
    $stack
}

function Add-MapNode {
    param($Canvas, $Device, [double]$X, [double]$Y, [double]$Size)
    $category = Get-Category $Device.DeviceType
    $node = New-NodeVisual $category $Size (Get-DisplayName $Device) $Device.Ip ($Device.Ip -eq $script:SelectedIp)
    $node.Tag = $Device.Ip
    $node.Cursor = 'Hand'
    $node.ToolTip = "$($Device.DeviceType)`n$($Device.Ip)"
    $node.Add_MouseLeftButtonUp({
        $script:SelectedIp = $this.Tag
        $_.Handled = $true
        Update-View
    })
    [System.Windows.Controls.Canvas]::SetLeft($node, $X - 70)
    [System.Windows.Controls.Canvas]::SetTop($node, $Y - $Size / 2)
    [void]$Canvas.Children.Add($node)
}

#endregion

#region Side panel

function Add-Field($Panel, [string]$Label, [string]$Value) {
    if (-not $Value) { $Value = [string][char]0x2014 }
    [void]$Panel.Children.Add((New-Text $Label 11.5 '#8A93A6' 'Normal' '0,10,0,1'))
    [void]$Panel.Children.Add((New-Text $Value 13.5 '#E6E9EF' 'Normal' '0,0,0,0'))
}

function Show-Summary {
    $panel = $ui.DetailsPanel
    $panel.Children.Clear()
    if (-not $script:Result) {
        [void]$panel.Children.Add((New-Text 'Network overview' 17 '#E6E9EF' 'SemiBold' '0,0,0,8'))
        [void]$panel.Children.Add((New-Text 'Run a scan to see the devices on your network. Select a device on the map to see its details and open ports.' 13 '#8A93A6'))
        return
    }
    $devices = @($script:Result.Devices)
    $noun = $(if ($devices.Count -eq 1) { 'device' } else { 'devices' })
    [void]$panel.Children.Add((New-Text "$($devices.Count) $noun" 26 '#E6E9EF' 'SemiBold' '0,0,0,0'))
    [void]$panel.Children.Add((New-Text "on $($script:Result.Subnet)" 13 '#8A93A6' 'Normal' '0,0,0,2'))
    $when = ''
    try { $when = ([datetime]$script:Result.FinishedAt).ToString('g') } catch { }
    [void]$panel.Children.Add((New-Text "Scanned $when in $($script:Result.DurationSec)s" 12 '#8A93A6' 'Normal' '0,0,0,18'))
    [void]$panel.Children.Add((New-Text 'DEVICE TYPES' 11 '#8A93A6' 'SemiBold' '0,0,0,8'))

    $groups = $devices | Group-Object { (Get-Category $_.DeviceType).Name } | Sort-Object Count -Descending
    foreach ($g in $groups) {
        $category = Get-Category $g.Group[0].DeviceType
        $row = New-Object System.Windows.Controls.DockPanel -Property @{ Margin = '0,0,0,8' }
        $badge = New-IconBadge $category 30
        $badge.Margin = '0,0,10,0'
        [System.Windows.Controls.DockPanel]::SetDock($badge, 'Left')
        $count = New-Text ([string]$g.Count) 14 '#E6E9EF' 'SemiBold' '8,0,0,0'
        $count.VerticalAlignment = 'Center'
        [System.Windows.Controls.DockPanel]::SetDock($count, 'Right')
        $name = New-Text $category.Name 13.5 '#E6E9EF' 'Normal' '0'
        $name.VerticalAlignment = 'Center'
        [void]$row.Children.Add($badge)
        [void]$row.Children.Add($count)
        [void]$row.Children.Add($name)
        [void]$panel.Children.Add($row)
    }
    [void]$panel.Children.Add((New-Text 'Click a device for details.' 12 '#8A93A6' 'Normal' '0,12,0,0'))
}

function Show-Device($Device) {
    $panel = $ui.DetailsPanel
    $panel.Children.Clear()
    $category = Get-Category $Device.DeviceType

    $back = New-Object System.Windows.Controls.Button -Property @{ Content = "$([char]0x2039)  All devices"; Style = $window.FindResource('Btn'); HorizontalAlignment = 'Left'; Padding = '10,5'; Margin = '0,0,0,16' }
    $back.Add_Click({ $script:SelectedIp = $null; Update-View })
    [void]$panel.Children.Add($back)

    $badge = New-IconBadge $category 64
    $badge.HorizontalAlignment = 'Left'
    [void]$panel.Children.Add($badge)
    [void]$panel.Children.Add((New-Text (Get-DisplayName $Device) 19 '#E6E9EF' 'SemiBold' '0,12,0,0'))
    [void]$panel.Children.Add((New-Text $Device.DeviceType 13.5 $category.Color 'SemiBold' '0,2,0,2'))
    [void]$panel.Children.Add((New-Text $Device.TypeReason 12 '#8A93A6' 'Normal' '0,0,0,6'))

    $mac = $Device.Mac
    if ($mac -and $Device.RandomizedMac) { $mac += '  (private / randomized)' }
    $ping = 'No'
    if ($Device.RespondsToPing) { $ping = "Yes, $($Device.LatencyMs) ms" }
    Add-Field $panel 'IP address' $Device.Ip
    Add-Field $panel 'Host name' $Device.HostName
    Add-Field $panel 'Vendor' $Device.Vendor
    Add-Field $panel 'MAC address' $mac
    Add-Field $panel 'OS guess' $Device.OsGuess
    Add-Field $panel 'Responds to ping' $ping

    $ports = @($Device.OpenPorts)
    [void]$panel.Children.Add((New-Text "OPEN PORTS ($($ports.Count))" 11 '#8A93A6' 'SemiBold' '0,20,0,8'))
    $wrap = New-Object System.Windows.Controls.WrapPanel
    foreach ($p in $ports) {
        $chip = New-Object System.Windows.Controls.Border -Property @{
            Background = (Get-Brush '#202734'); BorderBrush = (Get-Brush '#2C3443'); BorderThickness = '1'
            CornerRadius = '5'; Padding = '8,3'; Margin = '0,0,6,6'
        }
        $chip.Child = New-Text "$($p.Port)  $($p.Service)" 12 '#E6E9EF' 'Normal' '0'
        [void]$wrap.Children.Add($chip)
    }
    if (-not $ports.Count) { [void]$wrap.Children.Add((New-Text 'None found in the scanned ports.' 12.5 '#8A93A6')) }
    [void]$panel.Children.Add($wrap)

    $deep = New-Object System.Windows.Controls.Button -Property @{
        Content = 'Scan ports 1-1024'; Style = $window.FindResource('Primary'); HorizontalAlignment = 'Left'; Margin = '0,12,0,0'; Tag = $Device.Ip
        IsEnabled = ($state.Status -ne 'running')
    }
    $deep.Add_Click({ Start-PortScan $this.Tag })
    [void]$panel.Children.Add($deep)
}

#endregion

function Update-View {
    Update-Map
    $rows = @()
    if ($script:Result) {
        $rows = @($script:Result.Devices | ForEach-Object {
            [pscustomobject]@{
                Ip = $_.Ip; Name = $_.HostName; DeviceType = $_.DeviceType; Vendor = $_.Vendor; Mac = $_.Mac
                Ports = (@($_.OpenPorts) | ForEach-Object { $_.Port }) -join ', '
            }
        })
    }
    $ui.DeviceGrid.ItemsSource = $rows
    $ui.SaveButton.IsEnabled = [bool]$script:Result

    $selected = $null
    if ($script:SelectedIp -and $script:Result) { $selected = $script:Result.Devices | Where-Object { $_.Ip -eq $script:SelectedIp } | Select-Object -First 1 }
    if ($selected) { Show-Device $selected } else { $script:SelectedIp = $null; Show-Summary }
}

#region Background work

function Start-Work {
    param([string]$Kind, [scriptblock]$Script, [object[]]$Arguments)
    if ($state.Status -eq 'running') { return }
    if ($script:Job) { $script:Job.PowerShell.Dispose(); $script:Job = $null }
    $state.Status = 'running'; $state.Kind = $Kind; $state.Error = $null; $state.Progress = 'Starting...'; $state.Result = $null
    $ps = [powershell]::Create()
    [void]$ps.AddScript($Script).AddArgument($modulePath).AddArgument($state)
    foreach ($a in $Arguments) { [void]$ps.AddArgument($a) }
    $script:Job = @{ PowerShell = $ps; Handle = $ps.BeginInvoke() }
    $script:WasRunning = $true
    Set-Status 'Starting...' $true
}

function Start-NetworkScan {
    $options = @{}
    if ($ui.SubnetBox.Text.Trim()) { $options.Subnet = $ui.SubnetBox.Text.Trim() }
    if ($ui.PortsBox.Text.Trim()) { $options.Ports = $ui.PortsBox.Text.Trim() }
    try {
        [void](Resolve-ScanTarget -Subnet $options.Subnet)
        if ($options.Ports) { [void](ConvertTo-PortList $options.Ports) }
    } catch {
        Set-Status $_.Exception.Message $false $true
        return
    }
    Start-Work 'scan' {
        param($ModulePath, $State, $Options)
        try {
            Import-Module $ModulePath
            $progress = { param($Message) $State.Progress = $Message }.GetNewClosure()
            $State.Result = Invoke-NetworkScan @Options -OnProgress $progress
            $State.Status = 'completed'
        } catch { $State.Error = $_.Exception.Message; $State.Status = 'failed' }
    } @(, $options)
}

function Start-PortScan([string]$Ip) {
    $state.Target = $Ip
    Start-Work 'ports' {
        param($ModulePath, $State, $Ip)
        try {
            Import-Module $ModulePath
            $State.Progress = "Scanning ports 1-1024 on $Ip..."
            $State.Result = @(Invoke-PortScan -Ip $Ip -Ports (ConvertTo-PortList '1-1024'))
            $State.Status = 'completed'
        } catch { $State.Error = $_.Exception.Message; $State.Status = 'failed' }
    } @($Ip)
    Update-View
}

$timer = New-Object System.Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(400)
$timer.Add_Tick({
    try {
        if ($state.Status -eq 'running') { Set-Status $state.Progress $true; return }
        if (-not $script:WasRunning) { return }
        $script:WasRunning = $false
        if ($state.Status -eq 'failed') { Set-Status "Failed: $($state.Error)" $false $true; Update-View; return }

        if ($state.Kind -eq 'scan') {
            $script:Result = $state.Result
            $script:SelectedIp = $null
            Set-Status "Found $($script:Result.DeviceCount) device(s) on $($script:Result.Subnet) in $($script:Result.DurationSec)s."
        } else {
            $device = $script:Result.Devices | Where-Object { $_.Ip -eq $state.Target } | Select-Object -First 1
            if ($device) {
                # Merge the deep scan with what was already known, then re-classify.
                $merged = @(@($device.OpenPorts) + @($state.Result) | Sort-Object Port -Unique)
                $device.OpenPorts = $merged
                $class = Get-DeviceType $device
                $device.DeviceType = $class.Type
                $device.TypeReason = $class.Reason
            }
            Set-Status "$(@($state.Result).Count) open ports in 1-1024 on $($state.Target)."
        }
        Update-View
    } catch { Set-Status $_.Exception.Message $false $true }
})
$timer.Start()

#endregion

#region Events

function Set-Tab([bool]$Map) {
    $ui.MapView.Visibility = $(if ($Map) { 'Visible' } else { 'Collapsed' })
    $ui.DeviceGrid.Visibility = $(if ($Map) { 'Collapsed' } else { 'Visible' })
    $ui.MapTab.Background = Get-Brush $(if ($Map) { '#2F6FDE' } else { '#232A36' })
    $ui.ListTab.Background = Get-Brush $(if ($Map) { '#232A36' } else { '#2F6FDE' })
}

$ui.ScanButton.Add_Click({ Start-NetworkScan })
$ui.MapTab.Add_Click({ Set-Tab $true })
$ui.ListTab.Add_Click({ Set-Tab $false })
$ui.MapCanvas.Add_MouseLeftButtonUp({ if ($script:SelectedIp) { $script:SelectedIp = $null; Update-View } })
$ui.DeviceGrid.Add_SelectionChanged({
    $row = $ui.DeviceGrid.SelectedItem
    if ($row -and $row.Ip -ne $script:SelectedIp) {
        $script:SelectedIp = $row.Ip
        Show-Device ($script:Result.Devices | Where-Object { $_.Ip -eq $row.Ip } | Select-Object -First 1)
    }
})

$ui.SaveButton.Add_Click({
    try {
        $dialog = New-Object Microsoft.Win32.SaveFileDialog -Property @{
            Filter = 'Scan file (*.json)|*.json|Spreadsheet (*.csv)|*.csv'
            FileName = "network-scan-$(Get-Date -Format 'yyyy-MM-dd-HHmm')"
        }
        if (-not $dialog.ShowDialog($window)) { return }
        if ($dialog.FileName -like '*.csv') {
            $script:Result.Devices | Select-Object Ip, HostName, DeviceType, Vendor, Mac, OsGuess, RespondsToPing,
                @{ n = 'OpenPorts'; e = { (@($_.OpenPorts) | ForEach-Object { $_.Port }) -join ' ' } } |
                Export-Csv -Path $dialog.FileName -NoTypeInformation -Encoding UTF8
        } else {
            ConvertTo-Json -InputObject $script:Result -Depth 6 | Set-Content -Path $dialog.FileName -Encoding UTF8
        }
        Set-Status "Saved to $($dialog.FileName)"
    } catch { Set-Status "Save failed: $($_.Exception.Message)" $false $true }
})

function Import-ScanFile([string]$Path) {
    $data = Get-Content -Path $Path -Raw | ConvertFrom-Json
    if (-not $data.Devices) { throw "$Path is not a NetScanner scan file." }
    foreach ($d in $data.Devices) { $d.OpenPorts = @($d.OpenPorts) }
    $script:Result = $data
    $script:SelectedIp = $null
    Update-View
    Set-Status "Opened $Path ($(@($data.Devices).Count) devices)."
}

$ui.OpenButton.Add_Click({
    try {
        $dialog = New-Object Microsoft.Win32.OpenFileDialog -Property @{ Filter = 'Scan file (*.json)|*.json' }
        if ($dialog.ShowDialog($window)) { Import-ScanFile $dialog.FileName }
    } catch { Set-Status "Open failed: $($_.Exception.Message)" $false $true }
})

$window.Add_Closing({
    $timer.Stop()
    if ($script:Job) { try { $script:Job.PowerShell.Stop(); $script:Job.PowerShell.Dispose() } catch { } }
})

#endregion

# Initial state
$default = Get-LocalNetwork | Where-Object { $_.Gateway } | Sort-Object Metric | Select-Object -First 1
if ($default) {
    $dot = "  $([char]0x00B7)  "
    $ui.NetworkText.Text = "$($default.InterfaceAlias)$dot$($default.IpAddress)$dot$($default.Cidr)$($dot)gateway $($default.Gateway)"
} else {
    $ui.NetworkText.Text = 'No network with a gateway detected. Enter a subnet to scan.'
}
Set-Tab (-not $List)
if ($Open) { Import-ScanFile $Open } else { Update-View }
if ($Select) { $script:SelectedIp = $Select; Update-View }

if ($Snapshot) {
    $window.Add_ContentRendered({
        $window.Dispatcher.Invoke([action]{ }, [System.Windows.Threading.DispatcherPriority]::ApplicationIdle)
        $root = $ui.Root
        $bitmap = New-Object System.Windows.Media.Imaging.RenderTargetBitmap ([int]$root.ActualWidth), ([int]$root.ActualHeight), 96, 96, ([System.Windows.Media.PixelFormats]::Pbgra32)
        $bitmap.Render($root)
        $encoder = New-Object System.Windows.Media.Imaging.PngBitmapEncoder
        $encoder.Frames.Add([System.Windows.Media.Imaging.BitmapFrame]::Create($bitmap))
        $stream = [System.IO.File]::Create($Snapshot)
        $encoder.Save($stream)
        $stream.Close()
        $window.Close()
    })
}

[void]$window.ShowDialog()
} catch {
    [void][System.Windows.MessageBox]::Show("NetScanner could not start:`n`n$($_.Exception.Message)`n`n$($_.InvocationInfo.PositionMessage)", 'NetScanner', 'OK', 'Error')
}
