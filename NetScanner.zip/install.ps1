<#
.SYNOPSIS
    Installs NetScanner for the current user (no admin needed).
.DESCRIPTION
    Copies the app to %LOCALAPPDATA%\Programs\NetScanner, creates Desktop and Start menu shortcuts,
    and registers it under Settings > Apps so it can be uninstalled from there.
    -Quiet skips the confirmation dialogs.
#>
param([switch]$Quiet)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework

$appName = 'NetScanner'
$version = '1.0.0'
$installDir = Join-Path $env:LOCALAPPDATA "Programs\$appName"
$desktopLink = Join-Path ([Environment]::GetFolderPath('Desktop')) "$appName.lnk"
$startLink = Join-Path ([Environment]::GetFolderPath('Programs')) "$appName.lnk"
$uninstallKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\$appName"
$powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'

function New-Shortcut([string]$Path) {
    $shell = New-Object -ComObject WScript.Shell
    $link = $shell.CreateShortcut($Path)
    $link.TargetPath = $powershell
    $link.Arguments = "-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$installDir\NetScannerApp.ps1`""
    $link.WorkingDirectory = $installDir
    $link.IconLocation = "$installDir\NetScanner.ico,0"
    $link.Description = 'Scan your network and see every connected device'
    $link.WindowStyle = 7   # start minimized so the PowerShell host doesn't flash
    $link.Save()
}

try {
    New-Item -ItemType Directory -Force -Path $installDir | Out-Null
    # Overwrite program files but keep user data such as the downloaded oui.tsv vendor list.
    Get-ChildItem -Path $PSScriptRoot -File |
        Where-Object { $_.Name -notin 'install.ps1', 'Install.bat' -and $_.Extension -ne '.zip' } |
        Copy-Item -Destination $installDir -Force
    Get-ChildItem -Path $installDir -File | Unblock-File

    New-Shortcut $desktopLink
    New-Shortcut $startLink

    New-Item -Path $uninstallKey -Force | Out-Null
    $values = @{
        DisplayName     = $appName
        DisplayVersion  = $version
        Publisher       = $appName
        DisplayIcon     = "$installDir\NetScanner.ico"
        InstallLocation = $installDir
        UninstallString = "`"$powershell`" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$installDir\uninstall.ps1`""
    }
    foreach ($name in $values.Keys) { Set-ItemProperty -Path $uninstallKey -Name $name -Value $values[$name] }
    Set-ItemProperty -Path $uninstallKey -Name NoModify -Value 1 -Type DWord
    Set-ItemProperty -Path $uninstallKey -Name NoRepair -Value 1 -Type DWord
    $sizeKb = [int]((Get-ChildItem $installDir -File | Measure-Object Length -Sum).Sum / 1KB)
    Set-ItemProperty -Path $uninstallKey -Name EstimatedSize -Value $sizeKb -Type DWord

    if (-not $Quiet) {
        $answer = [System.Windows.MessageBox]::Show(
            "NetScanner is installed.`n`nYou'll find it on your Desktop and in the Start menu. Uninstall it any time from Settings > Apps.`n`nOpen NetScanner now?",
            'NetScanner', 'YesNo', 'Information')
        if ($answer -eq 'Yes') { Start-Process $desktopLink }
    }
    "Installed to $installDir"
} catch {
    if (-not $Quiet) { [void][System.Windows.MessageBox]::Show("Installation failed:`n`n$($_.Exception.Message)", 'NetScanner', 'OK', 'Error') }
    throw
}
