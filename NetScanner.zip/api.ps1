<#
.SYNOPSIS
    Local REST API (and dashboard) for network device discovery and port scanning.
.DESCRIPTION
    Listens on http://localhost:<Port>/ only. Endpoints:
      GET  /                      Dashboard (HTML)
      GET  /api                   Endpoint list
      GET  /api/networks          Local network interfaces and subnets
      POST /api/scan              Start a device scan   (?subnet=&ports=&skipPorts=true, or the same keys as a JSON body)
      GET  /api/scan              Scan status / progress
      GET  /api/devices           Devices from the last scan   (?type=printer filters by device type)
      GET  /api/devices/{ip}      One device
      GET  /api/ports/{ip}        Port-scan any host now        (?ports=1-1024, default 1-1024)
.EXAMPLE
    .\api.ps1 -ScanOnStart
.EXAMPLE
    .\api.ps1 -Port 9000 -Subnet 192.168.1.0/24
#>
param(
    [int]$Port = 8080,
    [string]$Subnet,
    [string]$Ports,
    [switch]$AllowLarge,
    [switch]$ScanOnStart
)
$ErrorActionPreference = 'Stop'
$modulePath = Join-Path $PSScriptRoot 'NetScanner.psm1'
Import-Module $modulePath -Force

$state = [hashtable]::Synchronized(@{ Status = 'idle'; Progress = $null; Error = $null; StartedAt = $null; Result = $null })
$script:job = $null

function Start-Scan {
    param([hashtable]$Options)
    if ($state.Status -eq 'running') { return $false }
    if ($script:job) { $script:job.PowerShell.Dispose(); $script:job = $null }
    $state.Status = 'running'
    $state.Error = $null
    $state.Progress = 'Starting...'
    $state.StartedAt = (Get-Date).ToString('o')

    $ps = [powershell]::Create()
    [void]$ps.AddScript({
        param($ModulePath, $State, $Options)
        try {
            Import-Module $ModulePath
            $progress = { param($Message) $State.Progress = $Message }.GetNewClosure()
            $State.Result = Invoke-NetworkScan @Options -OnProgress $progress
            $State.Status = 'completed'
            $State.Progress = $null
        } catch {
            $State.Status = 'failed'
            $State.Error = $_.Exception.Message
            $State.Progress = $null
        }
    }).AddArgument($modulePath).AddArgument($state).AddArgument($Options)
    $script:job = @{ PowerShell = $ps; Handle = $ps.BeginInvoke() }
    $true
}

function Get-ScanStatus {
    $last = $null
    if ($state.Result) {
        $last = [ordered]@{ subnet = $state.Result.Subnet; finishedAt = $state.Result.FinishedAt; deviceCount = $state.Result.DeviceCount }
    }
    [ordered]@{ status = $state.Status; progress = $state.Progress; error = $state.Error; startedAt = $state.StartedAt; lastScan = $last }
}

function Get-ScanOptions {
    param($Request)
    $options = @{}
    if ($Subnet) { $options.Subnet = $Subnet }
    if ($Ports) { $options.Ports = $Ports }
    if ($AllowLarge) { $options.AllowLarge = $true }

    $body = $null
    if ($Request.HasEntityBody) {
        $reader = New-Object System.IO.StreamReader($Request.InputStream, $Request.ContentEncoding)
        $text = $reader.ReadToEnd()
        $reader.Close()
        if ($text.Trim()) { $body = $text | ConvertFrom-Json }
    }
    foreach ($name in 'subnet', 'ports', 'skipPorts') {
        $value = $Request.QueryString[$name]
        if ($null -eq $value -and $body -and $body.PSObject.Properties[$name]) { $value = $body.$name }
        if ($null -eq $value -or "$value" -eq '') { continue }
        switch ($name) {
            'subnet'    { $options.Subnet = [string]$value }
            'ports'     { $options.Ports = [string]$value }
            'skipPorts' { $options.SkipPorts = "$value" -in 'true', '1', 'yes' }
        }
    }
    # Validate up front so bad input gets a 400 instead of a failed background job.
    [void](Resolve-ScanTarget -Subnet $options.Subnet -AllowLarge:([bool]$options.AllowLarge))
    if ($options.Ports) { [void](ConvertTo-PortList $options.Ports) }
    $options
}

function Send-Text {
    param($Context, [string]$Text, [string]$ContentType, [int]$StatusCode = 200)
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $response = $Context.Response
    $response.StatusCode = $StatusCode
    $response.ContentType = $ContentType
    $response.Headers['Cache-Control'] = 'no-store'
    $response.ContentLength64 = $bytes.Length
    $response.OutputStream.Write($bytes, 0, $bytes.Length)
    $response.OutputStream.Close()
}

function Send-Json {
    param($Context, $Body, [int]$StatusCode = 200)
    Send-Text $Context (ConvertTo-Json -InputObject $Body -Depth 8) 'application/json; charset=utf-8' $StatusCode
}

function Invoke-Route {
    param($Context)
    $request = $Context.Request
    $method = $request.HttpMethod
    $path = $request.Url.AbsolutePath.TrimEnd('/')
    if (-not $path) { $path = '/' }

    if ($path -eq '/' -and $method -eq 'GET') {
        return Send-Text $Context ([System.IO.File]::ReadAllText((Join-Path $PSScriptRoot 'dashboard.html'))) 'text/html; charset=utf-8'
    }
    if ($path -eq '/api' -and $method -eq 'GET') {
        return Send-Json $Context ([ordered]@{
            'GET /api/networks'     = 'Local interfaces and subnets'
            'POST /api/scan'        = 'Start a device scan (?subnet=192.168.1.0/24&ports=common&skipPorts=false)'
            'GET /api/scan'         = 'Scan status and progress'
            'GET /api/devices'      = 'Devices from the last scan (?type=printer)'
            'GET /api/devices/{ip}' = 'One device'
            'GET /api/ports/{ip}'   = 'Port-scan a host now (?ports=1-1024)'
        })
    }
    if ($path -eq '/api/networks' -and $method -eq 'GET') {
        return Send-Json $Context @(Get-LocalNetwork)
    }
    if ($path -eq '/api/scan') {
        if ($method -eq 'GET') { return Send-Json $Context (Get-ScanStatus) }
        if ($method -eq 'POST') {
            try { $options = Get-ScanOptions $request }
            catch { return Send-Json $Context @{ error = $_.Exception.Message } 400 }
            if (-not (Start-Scan $options)) { return Send-Json $Context @{ error = 'A scan is already running.'; scan = Get-ScanStatus } 409 }
            return Send-Json $Context (Get-ScanStatus) 202
        }
        return Send-Json $Context @{ error = "Method $method not allowed." } 405
    }
    if ($path -eq '/api/devices' -and $method -eq 'GET') {
        $result = $state.Result
        if (-not $result) {
            return Send-Json $Context ([ordered]@{ scan = Get-ScanStatus; message = 'No scan has completed yet. POST /api/scan to start one.'; devices = @() })
        }
        $devices = @($result.Devices)
        $type = $request.QueryString['type']
        if ($type) { $devices = @($devices | Where-Object { $_.DeviceType -like "*$type*" }) }
        return Send-Json $Context ([ordered]@{
            subnet = $result.Subnet; gateway = $result.Gateway; scannedAt = $result.FinishedAt
            count = $devices.Count; devices = $devices
        })
    }
    if ($path -match '^/api/devices/([0-9.]+)$' -and $method -eq 'GET') {
        $ip = $Matches[1]
        $device = $null
        if ($state.Result) { $device = $state.Result.Devices | Where-Object { $_.Ip -eq $ip } | Select-Object -First 1 }
        if (-not $device) { return Send-Json $Context @{ error = "No device $ip in the last scan." } 404 }
        return Send-Json $Context $device
    }
    if ($path -match '^/api/ports/([^/]+)$' -and $method -eq 'GET') {
        $ip = $Matches[1]
        try {
            [void](ConvertTo-IPNumber $ip)
            $spec = $request.QueryString['ports']
            if (-not $spec) { $spec = '1-1024' }
            $portList = ConvertTo-PortList $spec
        } catch { return Send-Json $Context @{ error = $_.Exception.Message } 400 }
        $watch = [System.Diagnostics.Stopwatch]::StartNew()
        $open = @(Invoke-PortScan -Ip $ip -Ports $portList)
        return Send-Json $Context ([ordered]@{
            ip = $ip; portsScanned = $portList.Count; durationSec = [math]::Round($watch.Elapsed.TotalSeconds, 1)
            openCount = $open.Count; openPorts = $open
        })
    }
    Send-Json $Context @{ error = "Not found: $method $path. See GET /api." } 404
}

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:${Port}/")
try { $listener.Start() }
catch { throw "Could not listen on port ${Port}: $($_.Exception.Message)" }

Write-Host "NetScanner API running at http://localhost:${Port}/  (Ctrl+C to stop)" -ForegroundColor Green
if ($ScanOnStart) {
    $startOptions = @{}
    if ($Subnet) { $startOptions.Subnet = $Subnet }
    if ($Ports) { $startOptions.Ports = $Ports }
    if ($AllowLarge) { $startOptions.AllowLarge = $true }
    [void](Start-Scan $startOptions)
    Write-Host 'Initial scan started.' -ForegroundColor DarkGray
}

try {
    while ($listener.IsListening) {
        $pendingContext = $listener.GetContextAsync()
        # Poll so Ctrl+C can interrupt between waits.
        while (-not $pendingContext.Wait(500)) { }
        $context = $pendingContext.Result
        try { Invoke-Route $context }
        catch {
            Write-Warning $_.Exception.Message
            try { Send-Json $context @{ error = $_.Exception.Message } 500 } catch { }
        }
        Write-Host ("{0:HH:mm:ss} {1} {2} -> {3}" -f (Get-Date), $context.Request.HttpMethod, $context.Request.Url.PathAndQuery, $context.Response.StatusCode) -ForegroundColor DarkGray
    }
} finally {
    $listener.Stop()
    $listener.Close()
    if ($script:job) { $script:job.PowerShell.Stop(); $script:job.PowerShell.Dispose() }
}
